# Vue.js Routing With vue-router
## Sample Application

This is the sample app of the tutorial __Vue.js Routing With vue-router__ available on [CodingTheSmartWay.com](http://codingthesmartway.com/).

## Online Course
Check out the online course: [Vue.js: From Beginner To Professional](http://codingthesmartway.com/courses/vue-beginner-professional)

## Build Setup

``` bash
# install dependencies
npm install

# serve with hot reload at localhost:8080
npm run dev

# build for production with minification
npm run build

# build for production and view the bundle analyzer report
npm run build --report
```
