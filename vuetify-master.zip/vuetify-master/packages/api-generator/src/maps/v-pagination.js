module.exports = {
  'v-pagination': {
    events: [
      {
        name: 'input',
        value: 'number',
      },
      {
        name: 'next',
        value: 'void',
      },
      {
        name: 'previous',
        value: 'void',
      },
    ],
  },
}
