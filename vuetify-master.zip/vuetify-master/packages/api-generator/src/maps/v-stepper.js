module.exports = {
  'v-stepper': {
    events: [
      {
        name: 'change',
        value: 'number',
      },
    ],
  },
  'v-stepper-step': {
    events: [
      {
        name: 'click',
        value: 'MouseEvent',
      },
    ],
  },
}
