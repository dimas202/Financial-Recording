module.exports = {
  'v-carousel': {
    events: [
      {
        name: 'input',
        value: 'number',
      },
    ],
  },
}
