module.exports = {
  'v-bottom-navigation': {
    events: [
      {
        name: 'change',
        value: 'any',
      },
      {
        name: 'update:input-value',
        value: 'string | number',
      },
    ],
  },
}
