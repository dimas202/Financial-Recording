module.exports = {
  'v-badge': {
    slots: [
      {
        name: 'badge',
        props: undefined,
      },
    ],
  },
}
