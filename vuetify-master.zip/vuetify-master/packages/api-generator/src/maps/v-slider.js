const { VSlider } = require('../helpers/variables')

module.exports = {
  'v-slider': VSlider,
}
