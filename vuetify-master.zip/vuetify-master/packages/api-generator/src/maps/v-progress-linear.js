module.exports = {
  'v-progress-linear': {
    slots: [
      {
        name: 'default',
        props: {
          value: 'number',
        },
      },
    ],
  },
}
