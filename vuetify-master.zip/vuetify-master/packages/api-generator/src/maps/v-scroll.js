module.exports = {
  'v-scroll': {
    options: [
      {
        name: 'arg:target',
        default: 'window',
        type: 'string',
      },
      {
        name: 'value',
        default: '(): {}',
        type: 'Function',
      },
    ],
  },
}
