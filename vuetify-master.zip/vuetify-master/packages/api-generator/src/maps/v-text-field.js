const { VTextField } = require('../helpers/variables')

module.exports = {
  'v-text-field': VTextField,
}
