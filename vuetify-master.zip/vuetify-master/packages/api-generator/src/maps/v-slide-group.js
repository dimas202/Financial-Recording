module.exports = {
  'v-slide-group': {
    events: [
      {
        name: 'click:location',
        value: 'void',
      },
    ],
    slots: [
      {
        name: 'next',
        value: undefined,
      },
      {
        name: 'prev',
        value: undefined,
      },
    ],
  },
}
