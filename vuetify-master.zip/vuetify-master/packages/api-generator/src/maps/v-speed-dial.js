module.exports = {
  'v-speed-dial': {
    slots: [
      {
        name: 'activator',
        props: undefined,
      },
    ],
  },
}
