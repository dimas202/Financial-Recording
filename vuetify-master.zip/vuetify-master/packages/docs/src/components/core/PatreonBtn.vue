<template>
  <v-btn
    active-class=""
    color="#F96854"
    dark
    href="https://www.patreon.com/vuetify"
    large
    rel="noopener"
    target="_blank"
    title="Support Vuetify through Patreon"
  >
    <v-img
      src="https://cdn.vuetifyjs.com/images/social/patreon-dark.png"
      width="24"
      class="mr-2"
    />
    <span
      class="font-weight-black"
      v-text="`Become a Patron`"
    />
  </v-btn>
</template>
