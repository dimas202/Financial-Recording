<template>
  <v-btn
    aria-label="Support Vuetify through OpenCollective"
    href="https://opencollective.com/vuetify"
    large
    rel="noopener"
    target="_blank"
    text
    title="Support Vuetify through OpenCollective"
  >
    <v-img
      alt="Open Collective Logo"
      src="https://opencollective.com/static/images/opencollective-icon.svg"
      class="mr-2"
      height="36"
      width="36"
    />
    <v-img
      alt="Open Collective Text"
      src="https://opencollective.com/static/images/logotype.svg"
      width="150"
    />
  </v-btn>
</template>
