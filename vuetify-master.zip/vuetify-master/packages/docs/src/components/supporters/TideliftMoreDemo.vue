<template>
  <div class="pa-4">
    <v-btn
      aria-label="Learn more about Tidelift"
      class="ma-1"
      color="#F6914D"
      height="32"
      href="https://tidelift.com/subscription/pkg/npm-vuetify?utm_source=vuetify&utm_medium=referral&utm_campaign=enterprise"
      outlined
      rel="noopener"
      style="background-color: #FFF !important;"
      target="_blank"
      title="Learn more about Tidelift"
      width="192"
    >
      Learn More
    </v-btn>
    <v-btn
      aria-label="Schedule a Tidelift demo"
      class="white--text ma-1"
      color="#F6914D"
      depressed
      height="32"
      href="https://tidelift.com/subscription/request-a-demo?utm_source=vuetify&utm_medium=referral&utm_campaign=enterprise"
      rel="noopener"
      target="_blank"
      title="Schedule a Tidelift demo"
      width="192"
    >
      Request a Demo
    </v-btn>
  </div>
</template>
