<template>
  <span class="subtitle-1 text-capitalize font-weight-light">
    <base-markdown><slot /></base-markdown>
  </span>
</template>

<script>
  export default {
    name: 'BaseNavText',
  }
</script>
