<template>
  <v-banner single-line>
    One line message text string with two actions on tablet / Desktop

    <template v-slot:actions>
      <v-btn
        text
        color="deep-purple accent-4"
      >
        Action
      </v-btn>
    </template>
  </v-banner>
</template>
