<template>
  <v-row justify="space-around">
    <v-color-picker class="ma-2" hide-canvas></v-color-picker>
    <v-color-picker class="ma-2" canvas-height="300"></v-color-picker>
    <v-color-picker class="ma-2" dot-size="30"></v-color-picker>
  </v-row>
</template>
