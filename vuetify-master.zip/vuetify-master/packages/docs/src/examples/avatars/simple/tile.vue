<template>
  <div class="text-center">
    <v-avatar tile color="blue">
      <v-icon dark>mdi-alarm</v-icon>
    </v-avatar>
  </div>
</template>
