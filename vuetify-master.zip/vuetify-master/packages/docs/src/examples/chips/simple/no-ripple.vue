<template>
  <v-row justify="center" align="center">
    <v-chip :ripple="false">Default</v-chip>
  </v-row>
</template>
