<template>
  <div class="text-center">
    <v-chip
      class="ma-2"
      x-small
    >
      x-small chip
    </v-chip>

    <v-chip
      class="ma-2"
      small
    >
      small chip
    </v-chip>

    <v-chip
      class="ma-2"
    >
      Default
    </v-chip>

    <v-chip
      class="ma-2"
      large
    >
      large chip
    </v-chip>

    <v-chip
      class="ma-2"
      x-large
    >
      x-large chip
    </v-chip>
  </div>
</template>
