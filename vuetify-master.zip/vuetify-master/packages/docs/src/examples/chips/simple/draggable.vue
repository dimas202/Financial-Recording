<template>
  <v-row justify="center" align="center">
    <v-chip draggable>Default</v-chip>
  </v-row>
</template>
