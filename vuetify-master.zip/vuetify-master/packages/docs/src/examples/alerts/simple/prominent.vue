<template>
  <div>
    <v-alert
      prominent
      type="error"
    >
      <v-row align="center">
        <v-col class="grow">Nunc nonummy metus. Nunc interdum lacus sit amet orci. Nullam dictum felis eu pede mollis pretium. Cras id dui.</v-col>
        <v-col class="shrink">
          <v-btn>Take action</v-btn>
        </v-col>
      </v-row>
    </v-alert>
    <v-alert
      color="blue-grey"
      dark
      dense
      icon="mdi-school"
      prominent
    >
      Sed augue ipsum, egestas nec, vestibulum et, malesuada adipiscing, dui. Aenean ut eros et nisl sagittis vestibulum. Sed aliquam ultrices mauris. Donec vitae orci sed dolor rutrum auctor.
    </v-alert>
    <v-alert
      icon="mdi-shield-lock-outline"
      prominent
      text
      type="info"
    >
      Donec quam felis, ultricies nec, pellentesque eu, pretium quis, sem. Sed in libero ut nibh placerat accumsan.. Curabitur blandit mollis lacus. Curabitur blandit mollis lacus.
    </v-alert>
  </div>
</template>
