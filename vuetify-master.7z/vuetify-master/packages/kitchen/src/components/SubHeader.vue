<template>
  <v-flex align-self-center>
    <h3 class="display-1 text-uppercase font-weight-light grey--text"><slot>Pan</slot></h3>
  </v-flex>
</template>

<script>
  export default {
    name: 'SubHeader',
  }
</script>
