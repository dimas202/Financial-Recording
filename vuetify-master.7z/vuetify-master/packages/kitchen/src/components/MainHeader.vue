<template>
  <v-flex align-self-center>
    <h2 class="display-2 text-uppercase font-weight-light grey-darken-1--text mt-4"><slot>Pan</slot></h2>
  </v-flex>
</template>

<script>
  export default {
    name: 'MainHeader',
  }
</script>
