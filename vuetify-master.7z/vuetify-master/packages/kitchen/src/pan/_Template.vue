<template>
  <v-container>
    <v-layout column>
      <main-header>Pan</main-header>

      <core-title>Title</core-title>
      <core-section>
        Content
      </core-section>
    </v-layout>
  </v-container>
</template>

<script>
  export default {
    name: '',

    data: () => ({}),
  }
</script>
