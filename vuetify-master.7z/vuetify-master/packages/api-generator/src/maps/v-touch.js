module.exports = {
  'v-touch': {
    options: [
      {
        name: 'value',
        default: '{}',
        type: 'object',
      },
    ],
  },
}
