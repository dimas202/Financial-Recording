module.exports = {
  'v-resize': {
    options: [
      {
        name: 'modifiers.quiet',
        default: 'false',
        type: 'boolean',
      },
      {
        name: 'value',
        default: 'undefined',
        type: 'Function',
      },
    ],
  },
}
