module.exports = {
  'v-btn-toggle': {
    events: [
      {
        name: 'change',
        value: 'any[] | any',
      },
    ],
  },
}
