module.exports = {
  'v-sparkline': {
    slots: [
      {
        name: 'label',
        value: undefined,
      },
    ],
  },
}
