module.exports = {
  $vuetify: {
    functions: [
      {
        name: 'goTo',
        signature: '(target: string | number | HTMLElement | VueComponent, options?: object): void',
      },
    ],
  },
}
