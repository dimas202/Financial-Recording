module.exports = {
  'v-divider': {
    props: [
      {
        name: 'dark',
        source: 'themeable',
      },
      {
        name: 'light',
        source: 'themeable',
      },
    ],
  },
}
