module.exports = {
  'v-col': {
    slots: ['default'],
  },
}
