module.exports = {
  'v-tab': {
    events: [
      {
        name: 'change',
        value: 'void',
      },
      {
        name: 'click',
        value: 'ClickEvent',
      },
      {
        name: 'keydown',
        value: 'KeyboardEvent',
      },
    ],
  },
}
