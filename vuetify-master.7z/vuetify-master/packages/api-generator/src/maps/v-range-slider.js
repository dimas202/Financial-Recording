const { VSlider } = require('../helpers/variables')

module.exports = {
  'v-range-slider': VSlider,
}
