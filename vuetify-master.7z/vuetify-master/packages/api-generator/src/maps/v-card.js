module.exports = {
  'v-card': {
    events: [
      {
        name: 'click',
        value: 'void',
      },
    ],
    slots: [
      {
        name: 'progress',
        props: undefined,
      },
    ],
  },
}
