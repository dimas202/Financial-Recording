module.exports = {
  'v-btn': {
    slots: [
      {
        name: 'loader',
        props: undefined,
      },
    ],
    events: [
      {
        name: 'click',
        value: 'Event',
      },
    ],
  },
}
