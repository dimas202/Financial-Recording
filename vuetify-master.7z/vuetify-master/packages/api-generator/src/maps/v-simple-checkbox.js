module.exports = {
  'v-simple-checkbox': {
    events: [
      {
        name: 'input',
        value: 'Event',
      },
    ],
  },
}
