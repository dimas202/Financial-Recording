module.exports = {
  'v-theme-provider': {},
}
