module.exports = {
  'v-progress-circular': {
    slots: [
      {
        name: 'default',
        props: {
          value: 'number',
        },
      },
    ],
  },
}
