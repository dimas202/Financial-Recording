module.exports = {
  'v-lazy': {
    slots: ['default'],
  },
}
