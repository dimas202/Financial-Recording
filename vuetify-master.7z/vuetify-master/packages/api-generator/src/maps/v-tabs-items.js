module.exports = {
  'v-tabs-items': {
    events: [
      {
        name: 'change',
        value: 'string',
      },
    ],
  },
}
