import VThemeProvider from './VThemeProvider'

export { VThemeProvider }
export default VThemeProvider
