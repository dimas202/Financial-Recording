import VFooter from './VFooter'

export { VFooter }
export default VFooter
