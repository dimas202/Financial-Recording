import VSnackbar from './VSnackbar'

export { VSnackbar }
export default VSnackbar
