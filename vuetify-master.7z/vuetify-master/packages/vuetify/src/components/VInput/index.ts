import VInput from './VInput'

export { VInput }
export default VInput
