import VSystemBar from './VSystemBar'

export { VSystemBar }
export default VSystemBar
