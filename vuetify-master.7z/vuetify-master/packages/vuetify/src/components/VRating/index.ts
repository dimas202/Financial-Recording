import VRating from './VRating'

export { VRating }
export default VRating
