import VBottomSheet from './VBottomSheet'

export { VBottomSheet }
export default VBottomSheet
