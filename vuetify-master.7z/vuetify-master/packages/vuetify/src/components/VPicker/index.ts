import VPicker from './VPicker'

export { VPicker }
export default VPicker
