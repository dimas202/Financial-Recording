import VSubheader from './VSubheader'

export { VSubheader }
export default VSubheader
