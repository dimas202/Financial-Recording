import VLazy from './VLazy'

export { VLazy }
export default VLazy
