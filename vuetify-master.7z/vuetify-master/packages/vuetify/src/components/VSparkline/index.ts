import VSparkline from './VSparkline'

export { VSparkline }

export default VSparkline
