import VSpeedDial from './VSpeedDial'

export { VSpeedDial }
export default VSpeedDial
