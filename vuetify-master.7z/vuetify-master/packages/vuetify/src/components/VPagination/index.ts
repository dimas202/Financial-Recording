import VPagination from './VPagination'

export { VPagination }
export default VPagination
