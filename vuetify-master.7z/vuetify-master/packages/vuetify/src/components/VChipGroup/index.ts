import VChipGroup from './VChipGroup'

export { VChipGroup }
export default VChipGroup
