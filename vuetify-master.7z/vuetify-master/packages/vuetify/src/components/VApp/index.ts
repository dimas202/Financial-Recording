import VApp from './VApp'

export { VApp }
export default VApp
