import VLabel from './VLabel'

export { VLabel }
export default VLabel
