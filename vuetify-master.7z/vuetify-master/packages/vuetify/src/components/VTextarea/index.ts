import VTextarea from './VTextarea'

export { VTextarea }
export default VTextarea
