import VResponsive from './VResponsive'

export { VResponsive }
export default VResponsive
