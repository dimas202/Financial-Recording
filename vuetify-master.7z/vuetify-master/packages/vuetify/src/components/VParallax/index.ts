import VParallax from './VParallax'

export { VParallax }
export default VParallax
