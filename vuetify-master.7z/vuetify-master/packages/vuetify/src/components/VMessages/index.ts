import VMessages from './VMessages'

export { VMessages }
export default VMessages
