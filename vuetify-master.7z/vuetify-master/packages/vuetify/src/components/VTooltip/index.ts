import VTooltip from './VTooltip'

export { VTooltip }
export default VTooltip
