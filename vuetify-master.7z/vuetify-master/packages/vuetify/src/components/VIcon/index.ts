import VIcon from './VIcon'

export { VIcon }
export default VIcon
