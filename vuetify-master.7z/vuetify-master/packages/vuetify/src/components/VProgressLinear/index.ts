import VProgressLinear from './VProgressLinear'

export { VProgressLinear }
export default VProgressLinear
