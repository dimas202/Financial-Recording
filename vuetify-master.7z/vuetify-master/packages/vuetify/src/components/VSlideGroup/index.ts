import VSlideGroup from './VSlideGroup'
import VSlideItem from './VSlideItem'

export {
  VSlideGroup,
  VSlideItem,
}

export default {
  $_vuetify_subcomponents: {
    VSlideGroup,
    VSlideItem,
  },
}
