import VColorPicker from './VColorPicker'
import VColorPickerSwatches from './VColorPickerSwatches'
import VColorPickerCanvas from './VColorPickerCanvas'

export { VColorPicker, VColorPickerSwatches, VColorPickerCanvas }
export default VColorPicker
