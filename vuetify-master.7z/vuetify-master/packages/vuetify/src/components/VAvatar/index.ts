import VAvatar from './VAvatar'

export { VAvatar }
export default VAvatar
