import VSwitch from './VSwitch'

export { VSwitch }
export default VSwitch
