import VFileInput from './VFileInput'

export { VFileInput }
export default VFileInput
