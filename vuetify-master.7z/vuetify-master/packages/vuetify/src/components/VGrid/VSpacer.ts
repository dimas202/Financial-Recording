import './_grid.sass'
import { createSimpleFunctional } from '../../util/helpers'

export default createSimpleFunctional('spacer', 'div', 'v-spacer')
