# Backers

You can join them in supporting Vuetify.js by [sponsoring through Github](https://www.patreon.com/vuetify)

### Premiere
- [QOMPLX](https://www.qomplx.com/)

### Diamond
- [LMAX Exchange](https://www.lmax.com/)
- [Intygrate](http://intygrate.com/)
- [Resale AI](http://resaleai.com/)
- [Vue Mastery](https://vuemastery.com/)

### Platinum
- [rateGenius](https://application.rategenius.com/) <!-- Ravi Alamuri -->
- [Clearblue Technologies](http://www.clearbluetechnologies.com/) <!-- Mark Windrim -->
- [DigitalMaas](https://www.digitalmaas.com/) <!-- Scott Francis -->
- [Brighttree](https://www.brightree.com/)
- [Asolvi](http://asolvi.com/) <!-- Sverre Dreier -->
- [Quanted Square](https://analytics.quantedsquare.com/)

### Gold
- [Xavier Escoté](http://www.deister.net/)
- [Zweidenker](http://zweidenker.de) <!-- Christian Denker -->
- [Software IDM](https://softwareidm.com/) <!-- Peter Sidebotham -->
- [Hohenstein Laboratories](https://www.hohenstein.de/en/home/home.xhtml)
- [P2L Technologies](https://p2l.tech/) <!-- Blaise Laflamme -->
- [madhead](https://www.madhead.com/) <!-- Terence Tsang -->
- [Elfo s.r.l.](https://www.elfo.net/)
- [Codefirst](https://www.codefirst.co.uk/)
- [customessaymeister](https://www.customessaymeister.com/)
- [blokt](https://blokt.com/)
- [Loomio](https://www.loomio.org/)
- Hannes Kochniß
- [EduBirdie](https://edubirdie.com/)
- [Toolio](https://www.toolio.com/)
- [JSDevJobs](https://jsdevjobs.com/)
- [Skale Technologies](http://www.skaletech.com/)
- [NoteRiot](https://note.riot.ai/)
- [EduBirdie](https://edubirdie.com/)
- [ClothingRIC](https://www.clothingric.com/)

### $20+
- pjcunningham
- malkhuzayyim
- chewy94
- austinginder
- busseyl
- Phlow2001
- SIDNEI LUIZ BAUMGARTENN
- Brad Stewart
- Kyle Lawhorn
- Working Group Two
- Kent Johnson
- Juha Vehnia
- Joel Hatch
- Robin Paolini
- Christo Crampton

### $10+
- centerorbit
- ivelin
- cloudwizard
- isokosan
- jraller
- ikedaosushi
- mantis
- flipvh
- hueachilles
- J-Sek
- erichelgeson
- dylancopeland
- P4sca1
- harrisonleong
- blalan05
- cebartling
- MarkFreedman
- shuogawa
- DRoet
- dantrevino
- appurist
- wallslide
- MichaelHipp
- margerum
- morphatic
- bjorkgard
- pacific202
- borisdayma
- jillztom
- goeh
- bdeo
- Mark Couvaras
- Esteban Miguel
- Bert Garza
- fanvyr
- Jonty Brook
- Daniel Chote
- Bohdan Kokotko
- Erik Vavro
- Salty Fish
- Quintin Donnell henry
- Christian Burkhart
- Stephen Elliot
- Jaeyoung Lee
- Adam Kaput
- Harold Bruton
- James Chang
- Pierre Vanhulst
- Helmi
- Idea Junction Ltd.
- Anthony Estebe
- Sam Bosell
- Philippe Genois
- Costa Huang
- Chava Sobreyra
